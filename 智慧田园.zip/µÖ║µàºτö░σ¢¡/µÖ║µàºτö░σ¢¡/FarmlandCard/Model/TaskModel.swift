//
//  TaskModel.swift
//  智慧田园
//
//  Created by jason on 16/5/23.
//  Copyright © 2016年 jason. All rights reserved.
//

import Foundation
public enum TaskStatus:String{
    case Finished = "_Finish"
    case Doing = "_UnFinish"
}
public enum TaskStyle:String{
    case Normal = "_Usual"
    case Temporary = "_Temporary"
}