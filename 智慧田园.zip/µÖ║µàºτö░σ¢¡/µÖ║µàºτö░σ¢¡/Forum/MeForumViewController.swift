//
//  MeForumViewController.swift
//  智慧田园
//
//  Created by jason on 16/5/22.
//  Copyright © 2016年 jason. All rights reserved.
//

import UIKit

class MeForumViewController: ForumViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的问题"
    }

}
